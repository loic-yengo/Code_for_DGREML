#include <string.h>
#include <math.h>
#include <cstdio>
#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <random>
using namespace std;

// Eigen include
#include "Eigen/Dense"
using namespace Eigen;


double static pdfBivGauss(double x, double y, double r){
  double r2 = r*r; double x2 = x*x; double y2 = y*y; double v = 1.-r2;
  double A  = exp( 0.5*(2.*r*x*y-r2*(x2 + y2))/v )/sqrt(v);
  return( A );
};

// Main funtion used on cov_files.txt with a sequential access
int main(int argc, char *argv[]){
  // Input arguments
  string prefix      = "none";
  string inputFile   = "none";
  bool verbose       =   true;
  double h2eq        =    0.8;      // Narrow sense heritability parameter in the equilibrium population
  int n              =      0;      // Number of individuals
  double r           =    0.2;
  int ng             =      1;      // Number of generations of AM
  int nc             =    100;      // Number of potential mates  
  int seed1          =     -1;
  int seed2          =     -1;
  int m              =   1000;      // Total number of SNPs
  int mc             =    100;      // Number of causal variants
  bool fixbeta       =  false;
  bool makeped       =  false;
  double p           =    0.5;
  int nchr           =      2;      // Number of chromosomes 
  
  // Indices
  string sw;
  int i,j,k;
  
  if(argc==1){
    cerr<<"\tArguments must be specified. Type --help for more details."<<endl;
    exit(1);
  }
  
  // Read arguments
  sw = argv[1];
  if (sw == "--help"){
    cerr<<"\t--r          : Phenotypic correlation between mates."<<endl;
    cerr<<"\t--m          : Total number of SNPs."<<endl;
    cerr<<"\t--mc         : Number of causal variants."<<endl;
    cerr<<"\t--nchr       : Number of chromosomes (default is 2)."<<endl;
    cerr<<"\t--n          : Sample size."<<endl;
    cerr<<"\t--nc         : Number of potential mates (default is 100)."<<endl;
    cerr<<"\t--ng         : Number of generations to simulate."<<endl;
    cerr<<"\t--h2eq       : SNP heritability."<<endl;
    cerr<<"\t--p          : Allele frequency."<<endl;
    cerr<<"\t--seed1      : Random Number Generator seed for the base population. Must be positive: >0."<<endl;
    cerr<<"\t--seed2      : Random Number Generator seed for following generations. Must be positive: >0."<<endl;
    cerr<<"\t--fix-beta   : When active all effect size are constant."<<endl;
    cerr<<"\t--make-ped   : plink files are generated [ped/map]."<<endl;
    cerr<<"\t--silent     : Nothing is outputed on the screen."<<endl;
    cerr<<"\t--out        : Prefix for output file: [prefix].sim."<<endl;
    cerr<<"\t[Note] Missing values are imputed to the major allele."<<endl;
    exit(1);
  }else{
    if (argc == 1) {
      cerr<<"\tArguments must be specified. Type --help for more details."<<endl;
      exit(1);
    }
  }
  
  for(i = 1; i<argc;i++){
    sw = argv[i];
    if (sw == "--n"){
      n = atoi(argv[i + 1]);
    }
    if (sw == "--m"){
      m = atoi(argv[i + 1]);
    }
    if (sw == "--mc"){
      mc = atoi(argv[i + 1]);
    }
    if (sw == "--nchr"){
      nchr = atoi(argv[i + 1]);
    }
    if (sw == "--silent"){
      verbose = false;
    }
    if (sw == "--make-ped"){
      makeped = true;
    }
    if (sw == "--r"){
      r = atof(argv[i + 1]);
    }
    if (sw == "--fix-beta"){
      fixbeta = true;
    }
    if (sw == "--h2eq"){
      h2eq = atof(argv[i + 1]);
    }
    if (sw == "--input"){
      inputFile = argv[i + 1];
    }
    if (sw == "--seed1"){
      seed1 = atoi(argv[i + 1]);
    }
    if (sw == "--seed2"){
      seed2 = atoi(argv[i + 1]);
    }
    if (sw == "--p"){
      p = atof(argv[i + 1]);
    }
    if (sw == "--out"){
      prefix = argv[i + 1];
    }
    if (sw == "--ng"){
      ng = atoi(argv[i + 1]);
    }
    if (sw == "--nc"){
      nc = atoi(argv[i + 1]);
    }
  }
  if(h2eq>1. or h2eq<0.){
    cerr<<"\tHeritability parameter must be between 0 and 1. Use option --h2."<<endl;
    exit(1);
  }
  if(r>1. or r<0.){
    cerr<<"\tPhenotypic correlation between mates must be between 0 and 1. Use option --r."<<endl;
    exit(1);
  }
  
  double varA_eq         = h2eq;
  double varE            = 1.-h2eq; 
  double Q               = 1.-.5/mc;
  double rho             = r * h2eq;
  double varA_0          = varA_eq * (1.- Q * rho);
  double h2_0            = varA_0 / (varA_0 + varE); 
  double num             = 2.+(sqrt(1.-4.*Q*r*h2_0*(1.-h2_0))-1.)/h2_0;
  double den             = 2.*(1.-r*Q);
  double exp_inflation   = num/den;
  double exp_theta       = (exp_inflation-1)/(exp_inflation+1);
  double rh2_0           = r * h2_0;
  double exp_infOneGen   = 1 + rh2_0/2;
  double exp_thetaOneGen = rh2_0/(4. + rh2_0);
  double fracInflation   = 100. * exp_infOneGen / exp_inflation;
  double fracPairs       = (1.-1./((double) nchr))*(1. + 1./((double) m - 1.)); 
  
  if(verbose){
    cout<<"Simulation of "<<m<<" unlinked variants (including "<<mc<<" causals) spead across "<<nchr<<" chromosomes.\n";
    cout<<"Proportion of SNP-pairs used for analysis = "<<fracPairs<<".\n";
    cout<<"Simulation for "<<n<<" pairs of individuals.\n";
    cout<<"Specified heritability (eq.) h2 = "<<h2eq<<".\n";    
    cout<<"Specified correlation between mates r = "<<r<<".\n";
    cout<<"Specified number of potential mates nc = "<<nc<<".\n";
    cout<<"Specified number generation(s) ng = "<<ng<<".\n";
    cout<<endl;
    cout<<"Expected genetic variance/heritability in base population = "<<varA_0<<" / "<<h2_0<<".\n";
    cout<<"Expected inflation (at equilibrium) in genetic variance = "<<exp_inflation<<".\n";
    cout<<"Expected correlation (at equilibrium) odd vs even = "<<exp_theta<<".\n";
    cout<<endl;
    cout<<"Expected inflation (after one generation) in genetic variance = "<<exp_infOneGen<<".\n";
    cout<<"Expected correlation (after one generation) odd vs even = "<<exp_thetaOneGen<<".\n";
    cout<<endl;
    cout<<"Inflation after one generation = "<<fracInflation<<"% of the total inflation\n";
    cout<<endl;
  }
  
  // Random number generators
  //default_random_engine generator;
  mt19937 RNG1;
  if(seed1<0){
    seed1 = (unsigned) time(NULL);
  }
  RNG1.seed(seed1);

  double dp = 2 * p;
  double sp = sqrt( dp * (1. - p));

  // Sample effect sizes
  double sd_b    = sqrt(varA_0/mc);
  VectorXd b     = VectorXd::Zero(m);
  if(fixbeta){
    if(verbose){
      cout<<"Effect size fixed: b = "<<sd_b<<".\n";
    }
    for(j=0;j<m;j++){
      if(j<mc){
        b(j) = sd_b;
      }else{
        b(j) = 0.;
      }
    }
  }else{
    if(verbose){
      cout<<"Sampling effect sizes..."<<endl;
    }
    normal_distribution<double> rnorm_b(0.0,sd_b);
    for(j=0;j<m;j++){
      if(j<mc){
        b(j) = rnorm_b(RNG1);
      }else{ 
        b(j) = 0.;
      }
    }
  }
  double sum_bsq = b.squaredNorm(); 
  cout<<"ref_b = "<<sd_b<<endl;
  cout<<"Sum of b^2 = "<<sum_bsq<<endl;
  
  // Start 
  MatrixXi x  = MatrixXi::Zero(n,m); // genotypes current generation
  MatrixXi xn = MatrixXi::Zero(n,m); // genotypes next generation
  VectorXd e  = VectorXd::Zero(n);
  VectorXd g  = VectorXd::Zero(n);
  VectorXd y  = VectorXd::Zero(n);
  VectorXd ys = VectorXd::Zero(n); // scaled y
  
  // Simulate base population
  if(verbose){
    cout<<"Simulating base population..."<<endl;
  }
  
  double sd_e = sqrt(varE);
  normal_distribution<double> rnorm1_e(0.0,sd_e);
  binomial_distribution<int> BinomialBase(2,p);
  for(i=0;i<n;i++){
    e(i) = rnorm1_e(RNG1);
  }
  for(i=0;i<n;i++){
    g(i) = 0.0;
    for(j=0;j<m;j++){
      x(i,j)   = BinomialBase(RNG1);
      if(j<mc){
        g(i)    += b(j) * ( ( ((double) x(i,j) ) - dp ) / sp );
      }
    }
  }
  y = g + e;
  
  if(verbose){
    cout<<"Simulating base population [done]."<<endl;
  }
  
  
  double mean_e  = e.mean(); 
  double var_e   = e.squaredNorm()/(n-1) - mean_e * mean_e * (1. + 1. / (n-1));
  double mean_g  = g.mean();
  double var_g   = g.squaredNorm()/(n-1) - mean_g * mean_g * (1. + 1. / (n-1));
  double mean_y  = y.mean();
  double var_y   = y.squaredNorm()/(n-1) - mean_y * mean_y * (1. + 1. / (n-1));

  if(verbose){
    cout<<"E[e] = "<<mean_e<<" - var(e) = "<<var_e<<" (Base Population).\n";
    cout<<"E[g] = "<<mean_g<<" - var(g) = "<<var_g<<" (Base Population).\n";
    cout<<"E[y] = "<<mean_y<<" - var(y) = "<<var_y<<" (Base Population).\n";
  }
 

  mt19937 RNG2;
  if(seed2<0){
    seed2 = (unsigned) time(NULL);
  }
  RNG2.seed(seed2);
 
  // Joint probabilities
  VectorXd y0       = VectorXd::Zero(n);
  VectorXd y1       = VectorXd::Zero(n);
  VectorXi ipair    = VectorXi::Zero(n);
  VectorXi jpair    = VectorXi::Zero(n);

  MatrixXi x0 = MatrixXi::Zero(n,m);
  MatrixXi x1 = MatrixXi::Zero(n,m);
  
  // randomly sampling values between 0 and n-1
  uniform_int_distribution<int> samplingIndividual(0,n-1);
  normal_distribution<double> rnorm2_e(0.0,sd_e);
  uniform_real_distribution<double> runif(0.0,1.0);
  
  // Sample pairs
  VectorXi ic = VectorXi::Zero(nc);
  VectorXd Pc = VectorXd::Zero(nc);
  
  // Monitored
  int i0,i1;
  
  // Starting simulations
  int iGen, iGenp1;
  for(iGen=0;iGen<ng;iGen++){
    iGenp1 = 1 + iGen;
    if(verbose){
      cout<<"Simulating generation..."<<iGenp1<<": ";
    }
    
    // Scale y
    double mean_y = y.mean();
    double sd_y   = y.squaredNorm() / (n-1) - mean_y * mean_y * (1. + 1. / (n-1));
    for(i=0;i<n;i++){
      ys(i) = ( y(i) - mean_y ) / sd_y; 
    }
    
    // sampling mates...
    for(i=0;i<n;i++){
      i0 = samplingIndividual(RNG2); // this one is randomly sampled from the population to mate
      // let's find them a mate among nc random potential mates
      for(j=0;j<nc;j++){
        k     = samplingIndividual(RNG2); // replace with RNG2
        ic(j) = k;
        if(k==i0){
          Pc(j) = 0.; // no selfing allowed
        }else{
          Pc(j) = pdfBivGauss(ys(i0),ys(k),r);
        }
      }
      Pc = Pc / Pc.sum();
      //k  = rmultinom(Pc,nc);
      double thresh = runif(RNG2);
      k = 0;
      double cdf = 0.;
      while( k < nc ){
        cdf += Pc(k);
        if(thresh<=cdf){
          break;
        }
        k++;
      }
      if(k==nc){
        k = nc - 1;
      }
      i1 = ic(k);
      ipair(i) = i0;
      jpair(i) = i1;
    }
    
    // Calculate mean, variance and correlations
    double m0, m1;
    double v0, v1;
    double C01 = 0.;
    m0 = m1 = 0.;
    v0 = v1 = 0.;
    for(i=0;i<n;i++){
      m0 += ys( ipair(i) );
      m1 += ys( jpair(i) );
      C01+= ys( ipair(i) ) * ys( jpair(i) );
      v0 += ys( ipair(i) ) * ys( ipair(i) );
      v1 += ys( jpair(i) ) * ys( jpair(i) );
    }
    m0  = m0 / n;
    m1  = m1 / n;
    C01 = C01 / (n-1) - m0 * m1 * (1. + 1. / (n-1));;
    v0  = v0/(n-1) - m0 * m0 * (1. + 1. / (n-1));
    v1  = v1/(n-1) - m1 * m1 * (1. + 1. / (n-1));
    
    double rEmp = C01 / sqrt(v0 * v1);
    if(verbose){
      cout<<"r = "<<r<<" - r(Emp) = "<<rEmp<<"."<<endl;
    }
    
    // Generate offspring
    // e
    for(i=0;i<n;i++){
      e(i) = rnorm2_e(RNG2);
    }
    // Update x and g
    for(i=0;i<n;i++){
      g(i) = 0.0;
      for(j=0;j<m;j++){
        double p0_j  = 0.5 * (double) x(ipair(i),j);
        double p1_j  = 0.5 * (double) x(jpair(i),j);
        binomial_distribution<int> rbern_x0(1,p0_j);
        binomial_distribution<int> rbern_x1(1,p1_j);
        xn(i,j)   = rbern_x0(RNG2) + rbern_x1(RNG2);
        if(j<mc){
          g(i) += b(j) * ( ( ((double) xn(i,j)) - dp ) / sp );
        }
      }
    }
    y = g + e;
    x = xn;
  }

    
  mean_e  = e.mean();
  var_e   = e.squaredNorm()/(n-1) - mean_e * mean_e * (1. + 1. / (n-1));

  mean_g  = g.mean();
  var_g   = g.squaredNorm()/(n-1) - mean_g * mean_g * (1. + 1. / (n-1));

  mean_y  = y.mean();
  var_y   = y.squaredNorm()/(n-1) - mean_y * mean_y * (1. + 1. / (n-1));
  
  if(verbose){
    cout<<"E[e] = "<<mean_e<<" - var(e) = "<<var_e<<" (Equilibrium Population).\n";
    cout<<"E[g] = "<<mean_g<<" - var(g) = "<<var_g<<" (Equilibrium Population).\n";
    cout<<"E[y] = "<<mean_y<<" - var(y) = "<<var_y<<" (Equilibrium Population).\n";
  }
    

  string iid;
  if(verbose){
    cout<<"Writing phen file..."<<endl;
  }
  string phenfile = prefix+".phen";
  ofstream filephen(phenfile.c_str());
  for(i=0;i<n;i++){
    iid = prefix+to_string(i);
    filephen<<iid<<" "<<iid<<" "<<y(i)<<endl;
  }
  filephen.close();
  if(verbose){
    cout<<"Writing phen file [done]."<<endl;
  }
  
  if(makeped){
    string  pid, mid;
    if(verbose){
      cout<<"Writing ped file..."<<endl;
    }
    // Ped file
    string pedfile = prefix+".ped";
    ofstream fileped(pedfile.c_str());
    for(i=0;i<n;i++){
      iid = prefix+to_string(i);
      pid = prefix+"_dad_"+to_string(ipair(i));
      mid = prefix+"_mum_"+to_string(jpair(i));
      fileped<<iid<<" "<<iid<<" "<<pid<<" "<<mid<<" 1 1";
      for(j=0;j<m;j++){
        if(x(i,j)==0) fileped<<" "<<"A A";
        if(x(i,j)==1) fileped<<" "<<"A G";
        if(x(i,j)==2) fileped<<" "<<"G G"; 
      }
      fileped<<endl;
    }
    fileped.close();
    if(verbose){
      cout<<"Writing ped file [done]"<<endl;
    }
    // Map file
    if(verbose){
      cout<<"Writing map file..."<<endl;
    }
    string mapfile = prefix+".map";
    ofstream filemap(mapfile.c_str());
    int chr;
    for(j=0;j<m;j++){
      chr = 1 + j%nchr;
      filemap<<chr<<" snp"<<j<<" "<<j<<endl;
    }
    filemap.close();
    if(verbose){
      cout<<"Writing map file [done]"<<endl;
    }
  }else{
    if(verbose){
      cout<<"** plink files were not generated. **"<<endl;
    }
  }
  return EXIT_SUCCESS;
}


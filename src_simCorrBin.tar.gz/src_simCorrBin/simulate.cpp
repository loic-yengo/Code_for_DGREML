// This the version from Sep 23rd 2021 - LY
//#include <string.h>
#include <math.h>
#include <cstdio>
#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <random>
using namespace std;

// Eigen include
#include "Eigen/Dense"
using namespace Eigen;

// Main funtion used on cov_files.txt with a sequential access
int main(int argc, char *argv[]){
  // Input arguments
  string prefix      = "none";
  bool verbose       =   true;
  double h2eq        =    0.8;      // Narrow sense heritability parameter in the equilibrium population
  int n              =      0;      // Number of individuals
  int m              =   1000;      // Number of causal variants
  double r           =    0.2;
  int seed           =     -1;
  bool fixbeta       =  false;
  bool makeped       =  false;
  bool makegrm       =  false;
  int nchr           =      2;      // Number of chromosomes 
  int m_null         =      0;      // Number of null SNPs
 
  // Indices
  string sw;
  int i,j,k;
  
  if(argc==1){
    cerr<<"\tArguments must be specified. Type --help for more details."<<endl;
    exit(1);
  }
  
  // Read arguments
  sw = argv[1];
  if (sw == "--help"){
    cerr<<"\t--n          : Number of individuals to simulate."<<endl;
    cerr<<"\t--r          : Phenotypic correlation between mates."<<endl;
    cerr<<"\t--m          : Number of causal variants."<<endl;
    cerr<<"\t--m-null     : Number of null (non-causal) SNPs added to the GRM [default is m_null = 0]."<<endl;
    cerr<<"\t--nchr       : Number of chromosomes (default is 2)."<<endl;
    cerr<<"\t--h2eq       : SNP heritability in equilibrium population."<<endl;
    cerr<<"\t--seed       : Random Number Generator seed. Must be positive: >0."<<endl;
    cerr<<"\t--fix-beta   : When active all effect size are constant."<<endl;
    cerr<<"\t--make-ped   : plink files are generated [ped/map]."<<endl;
    cerr<<"\t--make-grm   : Two GRMs files are generated [.grm.*/.gpd.grm.*]."<<endl;
    cerr<<"\t--silent     : Nothing is outputed on the screen."<<endl;
    cerr<<"\t--out        : Prefix for output file: [prefix].sim."<<endl;
    cerr<<"\t[Note] Missing values are imputed to the major allele."<<endl;
    exit(1);
  }else{
    if (argc == 1) {
      cerr<<"\tArguments must be specified. Type --help for more details."<<endl;
      exit(1);
    }
  }
  
  for(i = 1; i<argc;i++){
    sw = argv[i];
    if (sw == "--n"){
      n = atoi(argv[i + 1]);
    }
    if (sw == "--m"){
      m = atoi(argv[i + 1]);
    }
    if (sw == "--m-null"){
      m_null = atoi(argv[i + 1]);
    }
    if (sw == "--nchr"){
      nchr = atoi(argv[i + 1]);
    }
    if (sw == "--silent"){
      verbose = false;
    }
    if (sw == "--make-ped"){
      makeped = true;
    }
    if (sw == "--make-grm"){
      makegrm = true;
    }
    if (sw == "--r"){
      r = atof(argv[i + 1]);
    }
    if (sw == "--fix-beta"){
      fixbeta = true;
    }
    if (sw == "--h2eq"){
      h2eq = atof(argv[i + 1]);
    }
    if (sw == "--seed"){
      seed = atoi(argv[i + 1]);
    }
    if (sw == "--out"){
      prefix = argv[i + 1];
    }
  }
  if(h2eq>1. or h2eq<0.){
    cerr<<"\tHeritability parameter must be between 0 and 1. Use option --h2."<<endl;
    exit(1);
  }
  if(r>1. or r<0.){
    cerr<<"\tPhenotypic correlation between mates must be between 0 and 1. Use option --r."<<endl;
    exit(1);
  }

  double varA_eq         = h2eq;
  double varE            = 1.-h2eq; 
  double Q               = 1.-.5/m;
  double rho             = r * h2eq;
  double varA_0          = varA_eq * (1.- Q * rho);
  double h2_0            = varA_0 / (varA_0 + varE); 
  double num             = 2.+(sqrt(1.-4.*Q*r*h2_0*(1.-h2_0))-1.)/h2_0;
  double den             = 2.*(1.-r*Q);
  double exp_inflation   = num/den;
  double exp_theta       = (exp_inflation-1)/(exp_inflation+1);
  double rh2_0           = r * h2_0;
  double exp_infOneGen   = 1 + rh2_0/2;
  double exp_thetaOneGen = rh2_0/(4. + rh2_0);
  double fracInflation   = 100. * exp_infOneGen / exp_inflation;

  initParallel();
  int nThreads = nbThreads( );
  clock_t tic = clock();
  time_t t = time(0);   // get time now
  struct tm * now = localtime( & t );
  
  if(verbose){
    cout <<"Simulation starts : ";
    cout << (now->tm_year + 1900) << '-'
         << (now->tm_mon + 1) << '-'
         <<  now->tm_mday << " at "
         <<  now->tm_hour <<":"<<now->tm_min<<":"<<now->tm_sec
         <<  ".\n\n";
    cout<<"Default #Threads used is "<<nThreads<<".\n\n";
    cout<<"Simulation of "<<m<<" unlinked variants across "<<nchr<<" chromosomes.\n";
    cout<<"Simulation for "<<n<<" individuals.\n";
    cout<<"Specified heritability (eq.) h2 = "<<h2eq<<".\n";    
    cout<<"Specified correlation between mates r = "<<r<<".\n";
    cout<<endl;
    cout<<"Expected genetic variance/heritability in base population = "<<varA_0<<" / "<<h2_0<<".\n";
    cout<<"Expected inflation (at equilibrium) in genetic variance = "<<exp_inflation<<".\n";
    cout<<"Expected correlation (at equilibrium) odd vs even = "<<exp_theta<<".\n";
    cout<<endl;
    cout<<"Expected inflation (after one generation) in genetic variance = "<<exp_infOneGen<<".\n";
    cout<<"Expected correlation (after one generation) odd vs even = "<<exp_thetaOneGen<<".\n";
    cout<<endl;
    cout<<"Inflation after one generation = "<<fracInflation<<"% of the total inflation\n";
    cout<<endl;
  }
  
  //exit(0);
  //if(seed<0){
  //  srand(time(NULL));
  //}else{
  //  srand(seed);
  //}

  // Random number generators
  //default_random_engine generator;
  mt19937 generator;
  if(seed<0){
    seed = (unsigned) time(NULL);
  }
  generator.seed(seed);
  
  if(verbose){
     cout<<"RNG seed = "<<seed<<".\n";
   }

  bernoulli_distribution rbern(0.5); // return bool
  normal_distribution<double> rnorm(0.0,1.0);

  // Derived parameters
  int M      = 2 * m;

  // Start 
  MatrixXd z = MatrixXd::Zero(n,M);
  MatrixXd x = MatrixXd::Zero(n,M);
  VectorXd g = VectorXd::Zero(n);
  VectorXd e = VectorXd::Zero(n);
  VectorXd y = VectorXd::Zero(n);
  VectorXd c = VectorXd::Zero(n);

  // Simulate base population
  if(r==0.){
    if(verbose){
      cout<<"Simulating base population (undergoing random mating)..."<<endl;
    }
    for(i=0;i<n;i++){
      for(j=0;j<M;j++){
        if(rbern(generator)){
          x(i,j) = 1.0; 
        }else{
          x(i,j) = 0.0;
        }
      }
    }
  }else{
    if(verbose){
      cout<<"Simulating equlibrium population..."<<endl;
    }
    // AM theory
    double rx  = (varA_eq/varA_0-1.0)/(M-1); // alpha in Yengo et al. (2018)
    double rz  = sin ( M_PI * rx / 2.0);
    double C_a = sqrt(1. - rz);
    double C_b = (sqrt(1. + rz * (M-1)) - C_a) / M;
    
    // Simulate z and x
    for(i=0;i<n;i++){
      c(i) = 0.;
      for(j=0;j<M;j++){
        z(i,j)  = rnorm(generator);
        c(i)   += z(i,j);
      }
    }
    
    for(i=0;i<n;i++){
      for(j=0;j<M;j++){
        z(i,j)  = C_a * z(i,j) + C_b * c(i);
        k       = j/2;
        if(z(i,j)>0.){
          x(i,j) = 1.;
        }
      }
    }  
  }

  // Simulate genotypes and phenotype
  MatrixXd w     = MatrixXd::Zero(n,m);
  double sum_y   = 0.;
  double sum_y2  = 0.;
  double sum_g   = 0.;
  double sum_g2  = 0.;
  double sum_e   = 0.;
  double sum_e2  = 0.;

  // Simulate effect sizes
  VectorXd b     = VectorXd::Zero(m);
  double ref_b   = sqrt(varA_0/m);
  double sum_bsq = 0.;
  double sum_b   = 0.;

  if(fixbeta){
    if(verbose){
      cout<<"Effect size fixed: b = "<<ref_b<<".\n";
    }
    for(j=0;j<m;j++){
      b(j)     = ref_b;
      sum_b   += b(j);
      sum_bsq += b(j) * b(j);
    }
  }else{
    if(verbose){
      cout<<"Sampling effect sizes..."<<endl;
    }
    normal_distribution<double> rnorm_b(0.,ref_b); 
    for(j=0;j<m;j++){
      b(j)     = rnorm_b(generator);
      b(j)     = abs( b(j) );
      sum_b   += b(j);
      sum_bsq += b(j) * b(j);
    }
  }
  cout<<"ref_b = "<<ref_b<<endl;
  cout<<"Sum of b^2 = "<<sum_bsq<<endl;


  //Simulate residual effects  
  double se = sqrt(varE);
  normal_distribution<double> rnorm_e(0.,se);
  for(i=0;i<n;i++){
    e(i)    = rnorm_e(generator);
    sum_e  += e(i);
    sum_e2 += e(i) * e(i); 
  }

  double mean_e = sum_e / n;
  double var_e  = sum_e2 / (n-1) - mean_e * mean_e * (1. + 1. / (n-1));

  for(i=0;i<n;i++){
    g(i) = 0.;
    for(j=0;j<m;j++){
      k       = 2 * j;
      w(i,j)  = M_SQRT2 * ( x(i,k) + x(i,k+1) - 1. );
      g(i)   += b(j) * w(i,j);
    }
    sum_g  += g(i);
    sum_g2 += g(i) * g(i);

    y(i)    = g(i) + e(i);
    sum_y  += y(i);
    sum_y2 += y(i) * y(i); 
  }
  
  double mean_g = sum_g / n;
  double var_g  = sum_g2/(n-1) - mean_g * mean_g * (1. + 1. / (n-1));
  

  double mean_y = sum_y / n;
  double var_y  = sum_y2/(n-1) - mean_y*mean_y * (1. + 1. / (n-1));
  
  
  // center and scale phenotype
  double sd_y   = sqrt(var_y);
  for(i=0;i<n;i++){
    y(i) = (y(i) - mean_y)/sd_y;
  }
  
  if(verbose){
    cout<<"E[e] = "<<mean_e<<" - var(e) = "<<var_e<<".\n";
    cout<<"E[g] = "<<mean_g<<" - var(g) = "<<var_g<<".\n";
    cout<<"E[y] = "<<mean_y<<" - var(y) = "<<var_y<<".\n";
    cout<<"Simulating equilibrium population [done]."<<endl;
  }
  
  // Calculate GRM
  if(makegrm){
    if(verbose){
      cout<<"Calculating standard GRM..."<<endl;
    }
    string iid;
    MatrixXd G  = MatrixXd::Zero(n,n);
    MatrixXd H  = MatrixXd::Zero(n,n);
    double G_bar;
    double H_bar;
    if(m_null==0){
      G     = w * w.transpose() / m;
      G_bar = G.trace() / n;
    }else{
      if(verbose) cout<<"Adding "<<m_null<<" null SNPs to GRM calculation.\n";
      m += m_null;
      MatrixXd w_null  = MatrixXd::Zero(n,m_null);
      double X_ij;
      binomial_distribution<int> Binomial(2,0.5);
      for(i=0;i<n;i++){
        for(j=0;j<m_null;j++){
          X_ij = (double) Binomial(generator);
          w_null(i,j)  = M_SQRT2 * ( X_ij - 1. );      
        }
      }
      G = (w * w.transpose() + w_null * w_null.transpose()) / m;
      G_bar = G.trace() / n;
    }
    
    if(verbose){
      cout<<"Calculating standard GRM [done]."<<endl;
      cout<<endl;
      for(int j=0;j<5;j++){
        for(int k=0;k<5;k++){
          cout<<"\t"<<G(j,k);
        }
        cout<<endl;
      }
      cout<<endl;
      cout<<"Mean trace = "<<G_bar<<".\n";
    }
    
    if(verbose){
      cout<<"Calculating disequilibrium GRM..."<<endl;
    }
    // double m_n   = ((double) m)/((double) n);
    H           = (1./n) * G * G - (1./m) * G;
    H_bar = H.trace()  / n;
    H = (1. / H_bar) * H;
    
    if(verbose){
      cout<<"Calculating disequilibrium GRM [done]."<<endl;
      cout<<endl;
      for(int j=0;j<5;j++){
        for(int k=0;k<5;k++){
          cout<<"\t"<<H(j,k);
        }
        cout<<endl;
      }
      cout<<endl;
      cout<<"\tTrace of (unscaled) G/H: "<<G_bar<<" / "<<H_bar<<".\n\n";
    }
    
    if(verbose){
      cout<<"Writing GRM [binary]..."<<endl;
    }
    string grmfile = prefix+".grm.bin";
    fstream A_Bin(grmfile.c_str(), ios::out | ios::binary);
    if (!A_Bin) throw ("Error: can not open the file [" + grmfile + "] to write.");
    float f_buf = 0.0;
    int size = sizeof (float);
    for (i = 0; i < n; i++) {
      for (j = 0; j <= i; j++) {
        f_buf = (float) (G(i, j));
        A_Bin.write((char*) &f_buf, size);
      }
    }
    A_Bin.close();
    // ID
    string id = prefix+".grm.id";
    ofstream fileId(id.c_str());
    for(i=0;i<n;i++){
      iid = prefix+to_string(i);
      fileId<<iid<<" "<<iid<<endl;
    }
    fileId.close();
    if(verbose){
      cout<<"Writing GRM [binary] [done]"<<endl;
    }
    
    // Write GRM 2
    string grmfile2 = prefix+".gpd.grm.bin";
    fstream A_Bin2(grmfile2.c_str(), ios::out | ios::binary);
    if (!A_Bin) throw ("Error: can not open the file [" + grmfile2 + "] to write.");
    f_buf = 0.0;
    size = sizeof (float);
    for (i = 0; i < n; i++) {
      for (j = 0; j <= i; j++) {
        f_buf = (float) (H(i, j));
        A_Bin2.write((char*) &f_buf, size);
      }
    }
    A_Bin2.close();
    // ID
    string id2 = prefix+".gpd.grm.id";
    ofstream fileId2(id2.c_str());
    for(i=0;i<n;i++){
      iid = prefix+to_string(i);
      fileId2<<iid<<" "<<iid<<endl;
    }
    fileId2.close();
    if(verbose){
      cout<<"Writing GRM [binary] [done]"<<endl;
    }
  }
  

  string iid;
  if(verbose){
    cout<<"Writing phen file..."<<endl;
  }
  string phenfile = prefix+".phen";
  ofstream filephen(phenfile.c_str());
  for(i=0;i<n;i++){
    iid = prefix+to_string(i);
    filephen<<iid<<" "<<iid<<" "<<y(i)<<endl;
  }
  filephen.close();
  if(verbose){
    cout<<"Writing phen file [done]."<<endl;
  }

  if(makeped){
    string  pid, mid;
    if(verbose){
      cout<<"Writing ped file..."<<endl;
    }
    // Ped file
    string pedfile = prefix+".ped";
    ofstream fileped(pedfile.c_str());
    for(i=0;i<n;i++){
      iid = prefix+to_string(i);
      pid = prefix+"_dad_"+to_string(i);
      mid = prefix+"_mum_"+to_string(i);
      fileped<<iid<<" "<<iid<<" "<<pid<<" "<<mid<<" 1 1";
      for(j=0;j<M;j++){
        if(x(i,j)==1.){
          fileped<<" G";
        }else{
          fileped<<" A";
        }
      }
      fileped<<endl;
    }
    fileped.close();
    if(verbose){
      cout<<"Writing ped file [done]"<<endl;
    }
    // Map file
    if(verbose){
      cout<<"Writing map file..."<<endl;
    }
    string mapfile = prefix+".map";
    ofstream filemap(mapfile.c_str());
    int chr;
    for(j=0;j<m-m_null;j++){
      chr = 1 + j%nchr;
      filemap<<chr<<" snp"<<j<<" "<<j<<endl;
    }
    filemap.close();
    if(verbose){
      cout<<"Writing map file [done]"<<endl;
    }
  }else{
    if(verbose){
      cout<<"** plink files were not generated. **"<<endl;
    }
  }
 
  time_t t2 = time(0);   // get time now
  struct tm * now2 = localtime( & t2 );
  cout <<"Simulation ends: ";
  cout << (now2->tm_year + 1900) << '-'
       << (now2->tm_mon + 1) << '-'
       <<  now2->tm_mday << " at "
       <<  now2->tm_hour <<":"<<now2->tm_min<<":"<<now2->tm_sec
       << ".\n";

  clock_t toc = clock();
  double time_elapsed = (double)(toc - tic) / CLOCKS_PER_SEC;
  printf("\nTime elapsed: %f seconds.\n\n", time_elapsed / nThreads);
  
  return EXIT_SUCCESS;
}


